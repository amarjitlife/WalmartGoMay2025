
package main

import (
	"fmt"
)

//__________________________________________________

type Circle struct { // Associative Type
	X, Y, Radius int 
}

type Wheel struct {
	X, Y, Radius, Spokes int
}

func playWithCircleAndWheel() {
	var c Circle
	c.X = 10 
	c.Y = 20
	c.Radius = 50

	fmt.Println("Circle :", c )

	var w Wheel
	w.X = 11 
	w.Y = 22
	w.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel :", w )
}

//__________________________________________________

type Point1 struct {
	X int
	Y int
}

// BEST PRACTICE
//		Always Prefer Composition Rather Inheritance

// Composition Pattern
//		Alternative Of Inheritance
// Compositing Types
type Circle1 struct { 
	Center Point1 
	Radius int
}

type Wheel1 struct {
	Circle Circle1
	Spokes int
}

func playWithCircleAndWheel1() {
	var c Circle1 // c Is Instance Of Circle1 Types
	c.Center.X = 10 
	c.Center.Y = 20
	c.Radius = 50

	fmt.Println("Circle1 :", c )

	// c.X = 100 
	// c.Y = 200
	// c.Radius = 500

	// fmt.Println("Circle1 :", c )

	var w Wheel1
	w.Circle.Center.X = 11 
	w.Circle.Center.Y = 22
	w.Circle.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel1 :", w )

	// w.X = 111 
	// w.Y = 222
	// w.Radius = 555
	// w.Spokes = 244

	// fmt.Println("Wheel1 :", w )
}

//__________________________________________________

// struct Creates Associative Types
//		Type Of Types
type Point struct {
	X int 
	Y int
}

func ScalePoint( point Point, factor  int) Point {
	return Point{ point.X * factor, point.Y * factor }
}

func AddPoint( point1 Point, point2 Point ) Point {
	return Point{ point1.X + point2.X , point1.Y +point2.Y }
}

func playWithPointType() {
	point1 := Point{ 10, 20 }
	point2 := Point{ 100, 200 }
	point3 := Point{ 10, 20 }

	fmt.Println( "point1 : ", point1 )
	fmt.Println( "point2 : ", point2 )
	fmt.Println( "point3 : ", point3 )

	fmt.Println( point1.X == point2.X && point1.Y == point2.Y )
	fmt.Println( point1.X == point3.X && point1.Y == point3.Y )

	// Equality Works For struct Type Also.
	//		It Will Compare Members Of struct
	fmt.Println( "point1 == point2 : ", point1 == point2 )
	fmt.Println( "point1 == point3 : ", point1 == point3 )

	fmt.Println( "point1 *  5 : ", ScalePoint( point1, 5 )  )
	fmt.Println( "point2 * 10 : ", ScalePoint( point2, 10 ) )
	fmt.Println( "point3 *  2 : ", ScalePoint( point3, 2 ) )

	point4 := AddPoint( point1, point2 )
	fmt.Println( "point4 : ", point4 )

	point5 := AddPoint( point1, point3 )
	fmt.Println( "point5 : ", point5 )
}

//__________________________________________________


type Point2 struct {
	X int
	Y int 
}

// type Circle1 struct { 
// 		Center Point1 
// 		Radius int
// }

type Circle2 struct {
	Point2 			// Type/Structure Embedding
	Radius int
}

type Wheel2 struct {
	Circle2  		// Type/Structure Embedding
	Spokes int
}


func playWithCircle2AndWheel2() {
	var w Wheel2
	w.Circle2.Point2.X = 11
	w.Circle2.Point2.Y = 22
	w.Circle2.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel : ", w )

	// Can Access Directly Members Of Embedded Type
	w.X = 110 		// 	Compiler Will Generate Code w.Circle2.Point2.X = 110

	w.Y = 220
	w.Radius = 550
	w.Spokes = 240

	fmt.Println("Wheel : ", w )

	// Declarative Syntax Using Initialiser
	var ww Wheel2
	ww = Wheel2{ Circle2{ Point2{ 88, 99 }, 70 }, 90  }
	fmt.Println("Wheel : ", ww )

	// Declarative Syntax Using Labelled Initialiser 
	ww = Wheel2{ 
			// Label Circle2
			Circle2 : Circle2{ 
				Point2 : Point2{ 888, 999 }, 
				Radius : 700 }, 
			Spokes: 900,
		}
	fmt.Println("Wheel : ", ww )
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main( ) {
	fmt.Println("\n\nFunction: playWithCircleAndWheel")
	playWithCircleAndWheel()

	fmt.Println("\n\nFunction: playWithCircleAndWheel1")
	playWithCircleAndWheel1()

	fmt.Println("\n\nFunction: playWithPointType")
	playWithPointType()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
}

