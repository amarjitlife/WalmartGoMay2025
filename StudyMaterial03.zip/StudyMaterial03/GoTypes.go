package main

import (
	"fmt"
	// "math"
	"strings"
	"bytes"
	"strconv"
	// "cmplx"
)

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Complex Number
//		a + b i
//		float32, float64 Follows IEEE 754 Standard
//		complex64: Means a And b Are Type Of float32
//		complex128: Means a And b Are Type Of float64

func playWithComplexTypes() {
	var x complex128 = complex(1, 2) 	// 1 + 2i
	var y complex128 = complex(3, 4) 	// 3 + 4i
	fmt.Println( x )
	fmt.Println( y )
	fmt.Println( x + y  )
	fmt.Println( x * y  )
	fmt.Println( real( x ) )  
	fmt.Println( imag( x ) )  

	fmt.Println( 1i * 1i )  

	xx := 1 + 2i
	yy := 3 + 4i
	fmt.Println( xx )
	fmt.Println( yy )
	fmt.Println( xx + yy  )
	fmt.Println( xx * yy  )
	fmt.Println( real( xx ) )  
	fmt.Println( imag( xx ) )  
	// fmt.Println( cmplx.Sqrt( -1 ) )
}

//__________________________________________________

func basename( s string ) string {
	for i := len( s ) - 1 ; i >= 0 ; i-- {
		if s[i] == '/' {
			s = s[ i + 1 : ] // Slicing
			break
		}
	}

	// for i := len( s ) - 1 ; i >= 0 ; i-- {
	// 	if s[i] == '.' {
	// 		s = s[ : i ] // Slicing
	// 		break
	// 	}
	// }

	return s
}

func basenameAgain( s string ) string {
	slash := strings.LastIndex( s, "/" )
	s = s[ slash + 1 : ]

	// if dot := strings.LastIndex( s, "." ) ; dot >= 0 {
	// 	s = s[ : dot ]
	// }
	return s
}

func playWithBaseName() {
	fmt.Println( basename( "/home/amarjit/Documents/Trainings/WalmartMay2025/Progress/Hello.go" ) )
	fmt.Println( basename( "/home/amarjit/Documents/Trainings/WalmartMay2025/Progress" ) )

	fmt.Println( basenameAgain( "/home/amarjit/Documents/Trainings/WalmartMay2025/Progress/Hello.go" ) )
	fmt.Println( basenameAgain( "/home/amarjit/Documents/Trainings/WalmartMay2025/Progress" ) )
}

// Reference Link: strings Pacakge 
// 		https://pkg.go.dev/strings
//		https://go.dev/blog/strings

//__________________________________________________

// Unicode UTF8 Enconding
func playWithStringType() {
	s := "Hello World!"

	fmt.Println( s )
	fmt.Println("String Length: ", len( s ) )

	s1 := "Hello World!\uD55C"
	fmt.Println( s1 )
	fmt.Println("String Length: ", len( s1 ) )

	s2 := "Hello, World!\u1112\u1161\u11AB"
	fmt.Println( s2 )
	fmt.Println("String Length: ", len( s2 ) )

	fmt.Println("\u1112\u1161\u11AB")
	fmt.Println("\u1112")
	fmt.Println("\u1161")
	fmt.Println("\u11AB")

	fmt.Println( s[0], s[7])
	fmt.Println( s[ 0 : 5 ] )
	fmt.Println( s[ : 5 ] )
	fmt.Println( s[ 7 : ] )
	fmt.Println( s[ : ] )

	ss := "Left Foot"
	tt := ss // String Object Copied

	fmt.Println( ss )
	fmt.Println( tt )

	ss += ", and Right Foot"
	fmt.Println( ss )
	fmt.Println( tt )

	// cannot assign to ss[0] (neither addressable nor a map index expression)
	// ss[0] = 'M'
}

// Function: playWithStringType
// Hello World!
// String Length:  12
// Hello World!한
// String Length:  15
// Hello, World!한
// String Length:  22


//__________________________________________________

func playWithStringsFunctions() {
    fmt.Println("Contains:  ", strings.Contains("test", "es"))
    fmt.Println("Count:     ", strings.Count("test", "t"))
    fmt.Println("HasPrefix: ", strings.HasPrefix("test", "te"))
    fmt.Println("HasSuffix: ", strings.HasSuffix("test", "st"))
    fmt.Println("Index:     ", strings.Index("test", "e"))
    fmt.Println("Join:      ", strings.Join([]string{"a", "b"}, "-"))
    fmt.Println("Repeat:    ", strings.Repeat("a", 5))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", -1))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", 1))
    fmt.Println("Split:     ", strings.Split("a-b-c-d-e", "-"))
    fmt.Println("ToLower:   ", strings.ToLower("TEST"))
    fmt.Println("ToUpper:   ", strings.ToUpper("test"))
}

// In C Language
	// There Is No String Type In C
	// String Value Denoted By ""
	// String Is Sequence Of ASCII Characters Stored In char Type Array
	// In C
	//		String Follows ASCII Coding
	//		String Ends With '\0' Null ASCII Character In Memory

// In Go Language
	// A string is an immutable sequence of bytes. 
	// Strings may contain arbitrary data, including bytes with value 0, 
	// but usually they contain human-readable text. 

	// Text strings are conventionally interpreted as UTF-8-encoded 
	// sequences of Unicode Code Points (runes)
	// It Stores Unicode Characters

	// Internal Structure Of string Type In Go Langauge

		// type _string struct {
		// 		elements *byte // underlying bytes
		// 		len      int   // number of bytes
		// }

// The built-in len function returns the number of bytes (not runes) 
// in a string, and the index operation s[i] retrieves the i-th 
// byte of string s, where 0 ≤ i < len(s).

// The i-th byte of a string is not necessarily the i-th character 
// of a string, because the UTF-8 encoding of a non-ASCII code point 
// requires two or more bytes.

//__________________________________________________

func insertCommas( s string ) string {
	n := len( s )

	if n <= 3 { return s }
	return insertCommas( s[ : n - 3 ] ) + "," + s[ n - 3 : ]
}

func playWithInsertCommans() {
	fmt.Println( insertCommas( "12345678" ) )
	fmt.Println( insertCommas( "85948504950495012345678" ) )
}

//__________________________________________________
// Buffer Example

func intsToString( values []int ) string {
	var buffer bytes.Buffer

	buffer.WriteByte( '[' )

	for index, value := range values {
		fmt.Printf("\nAt Index: %d Value: %v", index, value)

		if index > 0 {
			buffer.WriteString( ", " )
		}
		fmt.Fprintf( &buffer, "%d", value )
	}
	buffer.WriteByte( ']' )

	return buffer.String()
}

func playWithIntToString() {
	fmt.Println("\nString: ", intsToString( []int{ 10, 20, 30 } ) )
	fmt.Println("\nString: ", intsToString( []int{ 10, 20, 30, 100, 200, 300 } ) )
	fmt.Println("\nString: ", intsToString( []int{ 1000, 2000, 3000, 1111 } ) )
}

// bytes Package
// 		Package bytes implements functions for the manipulation of byte slices. 
//		It is analogous to the facilities of the strings package.
// Reference Link:
// 		https://pkg.go.dev/bytes

//__________________________________________________

func playWithStringUnicode() {
	const something = `⌘`

	fmt.Printf("Plain String: %s \n", something)
	fmt.Printf("Plain String: %q \n", something)

	for i := 0 ; i < len( something ) ; i++ {
		fmt.Printf( " %x ", something[i] )
	}

	somethingAgain := "Hello, ⌘"

	fmt.Printf("Plain String: %s \n", somethingAgain)
	fmt.Printf("Plain String: %q \n", somethingAgain)

	for i := 0 ; i < len( somethingAgain ) ; i++ {
		fmt.Printf( " %x ", somethingAgain[i] )
	}

	somethingAgain1 := "Hello, 한瘔"
	fmt.Printf( " \n%s ", somethingAgain1 )
	fmt.Println( len( somethingAgain1 ) )
	fmt.Printf("Hex Bytes: ")
	for i := 0 ; i < len( somethingAgain1 ) ; i++ {
		fmt.Printf(" %x ", somethingAgain1[i] )
	}

	fmt.Println()
	for index, character := range somethingAgain1 {
		fmt.Printf("\nAt Index: %d\t Character: %q\t Hex: %x", index, character, character)
	}

	characterCount := 0 
	for _, _ = range somethingAgain1 {
		characterCount++
	}

	fmt.Println("\nUnicode Character Count: ", characterCount )

	x := 123
	y := fmt.Sprintf( "%d", x )

	fmt.Println( y )
	
	fmt.Println( strconv.Itoa( x ) )
	fmt.Println( strconv.Atoi( "8970" ) )

}

// Reference Link:
//		https://pkg.go.dev/strconv

//__________________________________________________


const (
	a = 1 
	b
	c = 2
	d
)

const (
	c0 = iota  	// c0 = 0
	c1 = iota 	// c1 = 1
	c2 = iota 	// c2 = 2
)

const (
	aa = 1 << iota 		// aa = 1  	( iota = 0 )  1 << 0  = 2^0
	bb = 1 << iota 		// bb = 2 	( iota = 1 )  1 << 1  = 2^1
	cc = 1 << iota 		// cc = 4 	( iota = 2 )  1 << 2  = 2^2
	xx = 3 				// 	 		( iota = 3 )  Unused iota Value
	dd = 1 << iota 		// dd = 8 	( iota = 4 )  1 << 4  = 2^4
)

const (
	u 			= iota * 42
	v float64 	= iota * 42
	w 			= iota * 42
)

const x = iota
const y = iota 


type Weekday int
// Following Two const Expressions Are Same

const (
	Sunday Weekday = iota
	Monday 
	Tuesday
	Wednesday
	Thursday
	Friday
	Saturday
)

// Above Code Is Equivalent To Following
// const (
// 		Sunday Weekday 	= iota
// 		Monday 			= iota 
// 		Tuesday			= iota
// 		Wednesday 		= iota
// 		Thursday		= iota
// 		Friday 			= iota
// 		Saturday 		= iota
// )


const (
    _ = 1 << (10 * iota)  	// 10 Raised To Power 0
    KiB // 1024  		 	// 10 Raised To Power 1 i.e. 10^1
    MiB // 1048576
    GiB // 1073741824
    TiB // 1099511627776
    PiB // 1125899906842624
    EiB // 1152921504606846976
    ZiB // 1180591620717411303424
    YiB // 1208925819614629174706176
)

func playWithConstantsAgain() {
	fmt.Println("a, b, c, d")	
	fmt.Println(a, b, c, d)

	fmt.Println("c0, c1, c2")
	fmt.Println(c0, c1, c2)

	fmt.Println("aa, bb, cc, dd")	
	fmt.Println(aa, bb, cc, dd)	
}

// Function: playWithConstantsAgain
// a, b, c, d
// 1 1 2 2
// c0, c1, c2
// 0 1 2

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main( ) {
	fmt.Println("\n\nFunction: playWithComplexTypes")
	playWithComplexTypes()

	fmt.Println("\n\nFunction: playWithBaseName")
	playWithBaseName()

	fmt.Println("\n\nFunction: playWithStringType")
	playWithStringType()

	fmt.Println("\n\nFunction: playWithStringsFunctions")
	playWithStringsFunctions()

	fmt.Println("\n\nFunction: playWithInsertCommans")
	playWithInsertCommans()

	fmt.Println("\n\nFunction: playWithIntToString")
	playWithIntToString()

	fmt.Println("\n\nFunction: playWithStringUnicode")
	playWithStringUnicode()

	fmt.Println("\n\nFunction: playWithConstantsAgain")
	playWithConstantsAgain()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
}
