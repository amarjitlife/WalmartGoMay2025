
package main

import (
	"fmt"
	"math"
)

//___________________________________________________________________

// DESIGN PRINCIPLE
//		Design Towards Interfaces Rather Than Concrete Classes/Structure/State
//		Interfaces Defines Protocol Of Communication
//			It Forces Communication Contract Between Objects

// Interfaces Capability
//		What To Do!
//		It's Defines Communication Protocol Between Objects
//		Design Is Driven By Communication
//			i.e. Behaviour Driven Design

// Outcome Of It!
//		Loosely Coupled Design
//			Modularity, Maintainability, Resuability 
//				Are Immergent Properties Of System
// 
//___________________________________________________________________
// Interfaces Defines
//		Abstract Capability!
// 		What To Do!
type Superpower interface {
	Fly()
	SaveWorld()
}

//___________________________________________________________________
// In Java
//		Interfaces Are Explicitly Implemented On Concrete Types

// In Go/Python
//		Intefaces Are Implicitly Inferred For Concrete Structures

// Go Uses Duck Typing
// 		Definition : Duck Typing 
//			Anything Which Quack Like A Duck and Walk Like A Duck Is A Duck!

//	Anything Which Has Capability To Fly and SaveWorld Is Superpower
//		Hence Spiderman, Superman and Human Are Superpower
//		and Wonderwoman Is Not Superpower
// Structure Defines
// 		Concrete Capability
//		How, When, Where, Which Way To Do!
type Spiderman struct {}
type Superman struct {}
type Wonderwoman struct {}
type Human struct {} 

func (s Spiderman) Fly() {
	fmt.Println("Fly Like Spiderman!")
}

func (s Spiderman) SaveWorld() {
	fmt.Println("Save World Like Spiderman!")
}

func (s Superman) Fly() {
	fmt.Println("Fly Like Superman!")
}

func (s Superman) SaveWorld() {
	fmt.Println("Save World Like Superman!")
}

func (s Human) Fly() {
	fmt.Println("Fly Like Human!")
}

func (s Human) SaveWorld() {
	fmt.Println("Save World Like Human!")
}

//___________________________________________________________________

func playWith( power Superpower ) {
	power.Fly()
	power.SaveWorld()
}

func playWithAll() {
	spiderman 	:= Spiderman{ }
	playWith( spiderman )

	superman 	:= Superman{ }	
	playWith( superman )

	human 		:= Human{ }
	playWith( human )

	// wonderwoman := Wonderwoman{ } 
	// playWith( wonderwoman )
	// cannot use wonderwoman (variable of struct type Wonderwoman) 
	//		as Superpower value in argument to playWith: 
	//		Wonderwoman does not implement Superpower (missing method Fly)
}

// Function : playWithAll
// Fly Like Spiderman!
// Save World Like Spiderman!

//___________________________________________________________________

type Geometry interface {
	area() float64
	perimeter() float64
}

//___________________________________________________________________

type Rectangle struct { width, height float64 }
type Circle struct { radius float64 }
type Square struct { side float64 }

func ( r Rectangle ) area() float64 { return r.width * r.height }
func ( r Rectangle ) perimeter() float64 { return 2 * ( r.width + r.height ) }

func ( c Circle ) area() float64 { return math.Pi * c.radius * c.radius }
func ( c Circle ) perimeter() float64 { return 2 * math.Pi * c.radius }
func ( c Circle ) center() (float64, float64) { return 0.0, 0.0 }

// Polymorphic Function
//		Using Mechanism Interfaces
func calculateGeometry( g Geometry ) {
	fmt.Println("Geometry : ", g)
	fmt.Println("Geometry Area: ", g.area() )
	fmt.Println("Geometry Perimeter: ", g.perimeter() )
}

func playWithGeometry() {
	rectangle := Rectangle{ 10.0, 20.0 }
	calculateGeometry( rectangle ) //Go Infers Rectangle Type As Geometry

	circle := Circle{ 11.0 }
	calculateGeometry( circle )  //Go Infers Rectangle Type Is Not Geometry

	cx, cy := circle.center()
	fmt.Println( "Circle Center: ", cx, cy )

	square := Square{ 22.0 }
	fmt.Println("Squre: ", square)
	// calculateGeometry( square )
}

//___________________________________________________________________

// type Writer interface {
// 		Write(p []byte) (n int, err error)
// }

// Writer is the interface that wraps the basic Write method.

// type Reader interface {
// 		Read(p []byte) (n int, err error)
// }

// Reader is the interface that wraps the basic Read method.

// Writer is the interface that wraps the basic Write method.
//
// Write writes len(p) bytes from p to the underlying data stream.
// It returns the number of bytes written from p (0 <= n <= len(p))
// and any error encountered that caused the write to stop early.
// Write must return a non-nil error if it returns n < len(p).
// Write must not modify the slice data, even temporarily.
//
// Implementations must not retain p.
// type Writer interface {
// 		Write(p []byte) (n int, err error)
// }

// Closer is the interface that wraps the basic Close method.
//
// The behavior of Close after the first call is undefined.
// Specific implementations may document their own behavior.
// type Closer interface {
// 		Close() error
// }

// Seeker is the interface that wraps the basic Seek method.
//
// Seek sets the offset for the next Read or Write to offset,
// interpreted according to whence:
// [SeekStart] means relative to the start of the file,
// [SeekCurrent] means relative to the current offset, and
// [SeekEnd] means relative to the end
// (for example, offset = -2 specifies the penultimate byte of the file).
// Seek returns the new offset relative to the start of the
// file or an error, if any.
//
// Seeking to an offset before the start of the file is an error.
// Seeking to any positive offset may be allowed, but if the new offset exceeds
// the size of the underlying object the behavior of subsequent I/O operations
// is implementation-dependent.
// type Seeker interface {
// 		Seek(offset int64, whence int) (int64, error)
// }


//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithAll")
	playWithAll()

	fmt.Println("\nFunction : playWithGeometry")
	playWithGeometry()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
}

//___________________________________________________________________
//___________________________________________________________________
