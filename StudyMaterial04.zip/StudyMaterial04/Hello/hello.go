
package hello

func Hello() string {
	return "Hello World!!! Welcome To Go Modules!"
}


