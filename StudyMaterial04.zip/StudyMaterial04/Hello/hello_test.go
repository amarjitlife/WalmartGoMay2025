
package hello

import "testing"

func TestHello( t *testing.T ) {
	want := "Hello World!!! Welcome To Go Modules!"

	if got := Hello(); got != want {
		t.Errorf("Hello() = %q, want %q", got, want)
	}
}


