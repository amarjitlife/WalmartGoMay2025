
package main

import (
    "fmt"
    "example.com/greetings"
)

func main() {
    fmt.Println("Hello Modules!!!")   
    
    message := greetings.Hello("To All")
    fmt.Println(message)
}

