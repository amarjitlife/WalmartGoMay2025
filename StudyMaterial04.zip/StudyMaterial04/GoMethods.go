
package main

import (
	"fmt"
	"math"
	"image/color"
	"bytes"
)

//___________________________________________________________________

type Point struct {
	X, Y float64
}

// Function Taking Two Arguments Of Type Point
func Distance( p, q Point ) float64 {
	return math.Hypot( q.X - p.X, q.Y - p.Y  )
}

// Method: Function Binded With The Receiver Type
//		Member Function Of Reciever Type Point

// In C++/Java
//		Receiver Object Is this
//			this Is A Pointer To Current Object
//			What Will Be Type of this???
//		this Is Implicitly Passed To Member Function i.e. Method

// In Python 
//		Receiver Object Is self
//			What Will Be Type of self???
//			self Is A Pointer To Current Object
//		self Is Explicitly Passed To Member Function i.e. Method

// class Fruit:
// 		Method Or Member Function
// 			First Argument Is Always self
// 			self Is Passed Explicitly To Member Functions/Methods	
//     def printstate(self,state):
//         print(f"The orange is {state}")


// In C++/Java
// float64 Point::Distance( q Point ) { }

// In Go Language
//		Receiver Object Is Passed Explicitly
//			What Will Be Type of Reciever Object?
//				Receiver Type
// 		After func Keywork Specify Receiver Type: Point
//		p is Reciever Object Of Point Type
func (p Point) Distance( q Point ) float64 {
	return math.Hypot( q.X - p.X, q.Y - p.Y  )	
}

// If You Wants To Name Receiver Object this/self You Can
// func (this Point) Distance( q Point ) float64 {
// 		return math.Hypot( q.X - this.X, q.Y - this.Y  )	
// }

// func (self Point) Distance( q Point ) float64 {
// 		return math.Hypot( q.X - self.X, q.Y - self.Y  )	
// }

type Celsius float64
type Fahrenheit float64

// Similarly We Are Creating New Type Path
type Path []Point

func ( path Path ) Distance() float64 {
	sum := 0.0
	for i := range path {
		if i > 0 {
			sum += path[ i - 1 ].Distance( path[i] )
		}
	}
	return sum
} 

// Method ScaleBy For Receiver Type Point

// func (p Point) ScaleBy( factor float64 ) {
func (p * Point) ScaleBy( factor float64 ) {
	p.X = p.X * factor
	p.Y = p.Y * factor
}

// Similar Code To Above One
// func (this * Point) ScaleBy( factor float64 ) {
// 		this.X = p.X * factor
// 		this.Y = p.Y * factor
// }

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Than Mutability
//		If Object Not To Change Than Why Should Provide Chanbility
//		You Should Not Create Side Effect Until/Unless It's Required

func playWithFunctionsAndMethods() {
	var point1 = Point { 10.0, 20.0 }
	var point2 = Point { 100.0, 200.0 }

	fmt.Println("Distance Using Function: ", Distance( point1, point2 ) )
	fmt.Println("Distance Using Method  : ", point1.Distance( point2 ) )	

	var path Path = Path{ Point{ 10, 10 }, Point{ 20, 20 }, Point{ 30, 30 } }
	//										 Inooking Path Type Method Distance
	fmt.Println("Path Distance Using Method: ", path.Distance( ) )

	fmt.Println("Point: ", point1)
	point1.ScaleBy( 5 )
	fmt.Println("Point: ", point1)

	fmt.Println("Point: ", point2)
	point1.ScaleBy( 5 )
	fmt.Println("Point: ", point2)
}

// Function : playWithFunctionsAndMethods
// Distance Using Function:  201.24611797498108
// Distance Using Method  :  201.24611797498108
// Path Distance Using Method:  28.284271247461902
// Point:  {10 20}
// Point:  {10 20}
// Point:  {100 200}
// Point:  {100 200}

//___________________________________________________________________


type ColoredPoint struct { // Embedding Type
	Point 				// Embedded Type
	Color color.RGBA
}

func playWithColoredPointMethods() {
	red 	:= color.RGBA{ 255, 0, 0, 255 }
	blue 	:= color.RGBA{ 0, 0, 255, 255 }
	
	var cpoint1 = ColoredPoint{ Point{ 10, 20 }, red }
	var cpoint2 = ColoredPoint{ Point{ 11, 22 }, blue }

	// fmt.Println("Distance Method (Point): ", cpoint1.Distance( cpoint2 ) )
		//./GoMethods.go:139:60: cannot use cpoint2 
		//		(variable of struct type ColoredPoint) 
		//		as Point value in argument to cpoint1.Distance

	fmt.Println("Distance Method (Point): ", cpoint1.Distance( cpoint2.Point ) )

	fmt.Println("Point : ", cpoint1)
	cpoint1.ScaleBy( 2 )
	fmt.Println("Point : ", cpoint1)

	fmt.Println("Point : ", cpoint2)
	cpoint2.ScaleBy( 2 )
	fmt.Println("Point : ", cpoint2)
}

//___________________________________________________________________

// HOME WORK
// HOME WORK
// HOME WORK

//___________________________________________________________________

// An IntSet is a set of small non-negative integers.
// 		Its zero value represents the empty set.
type IntSet struct {
	words []uint64
}

// Has reports whether the set contains the non-negative value x.
func (s *IntSet) Has(x int) bool {
	word, bit := x/64, uint(x%64)
	return word < len(s.words) && s.words[word]&(1<<bit) != 0
}

// Add adds the non-negative value x to the set.
func (s *IntSet) Add(x int) {
	word, bit := x/64, uint(x%64)
	for word >= len(s.words) {
		s.words = append(s.words, 0)
	}
	s.words[word] |= 1 << bit
}

// UnionWith sets s to the union of s and t.
func (s *IntSet) UnionWith(t *IntSet) {
	for i, tword := range t.words {
		if i < len(s.words) {
			s.words[i] |= tword
		} else {
			s.words = append(s.words, tword)
		}
	}
}

// String returns the set as a string of the form "{1 2 3}".
func (s *IntSet) String() string {
	var buf bytes.Buffer
	buf.WriteByte('{')
	for i, word := range s.words {
		if word == 0 {
			continue
		}
		for j := 0; j < 64; j++ {
			if word&(1<<uint(j)) != 0 {
				if buf.Len() > len("{") {
					buf.WriteByte(' ')
				}
				fmt.Fprintf(&buf, "%d", 64*i+j)
			}
		}
	}
	buf.WriteByte('}')
	return buf.String()
}

//___________________________________________________________________

func playWithIntSet() {
	var x, y IntSet
	x.Add(1)
	x.Add(144)
	x.Add(9)
	fmt.Println(x.String()) // "{1 9 144}"

	y.Add(9)
	y.Add(42)
	fmt.Println(y.String()) // "{9 42}"

	x.UnionWith(&y)
	fmt.Println(x.String()) // "{1 9 42 144}"

	fmt.Println(x.Has(9), x.Has(123)) // "true false"

	// Output:
	// {1 9 144}
	// {9 42}
	// {1 9 42 144}
	// true false
}

//___________________________________________________________________

func playWithIntSetAgain() {
	var x IntSet
	x.Add(1)
	x.Add(144)
	x.Add(9)
	x.Add(42)

	fmt.Println( &x )         // "{1 9 42 144}"
	fmt.Println( x.String() ) // "{1 9 42 144}"
	fmt.Println(x)          // "{[4398046511618 0 65536]}"

	// Output:
	// {1 9 42 144}
	// {1 9 42 144}
	// {[4398046511618 0 65536]}
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithFunctionsAndMethods")
	playWithFunctionsAndMethods()

	fmt.Println("\nFunction : playWithColoredPointMethods")
	playWithColoredPointMethods()

	fmt.Println("\nFunction : playWithIntSet")
	playWithIntSet()

	fmt.Println("\nFunction : playWithIntSetAgain")
	playWithIntSetAgain()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
}

//___________________________________________________________________
//___________________________________________________________________
