
package learnJava;

//___________________________________________________________________

// Capability
//		What To Do!
//		It's Defines Communication Protocol Between Objects
//		Design Is Driven By Communication
//			i.e. Behaviour Driven Design

// DESIGN PRINCIPLE
//		Design Towards Interfaces Rather Than Concrete Classes/Structure/State

interface Superpower {
	public void fly();
	public void saveWorld();
}

// Capability
//		How, When, Where, Which Way To Do!
// class Spiderman {
class Spiderman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Spiderman!"); }
	public void saveWorld() { System.out.println("Save World Like Spiderman!"); }	
}

class Superman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Superman!"); }
	public void saveWorld() { System.out.println("Save World Like Superman!"); }	
}

class Wonderwoman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Wonderwoman!"); }
	public void saveWorld() { System.out.println("Save World Like Wonderwoman!"); }	
}

class HanumanJi implements Superpower {
	public void fly() 		{ System.out.println("Fly Like HanumanJi!"); }
	public void saveWorld() { System.out.println("Save World Like HanumanJi!"); }	
}

// class Human {
// 	public void fly() 		{ System.out.println("Fly Like Human!"); }
// 	public void saveWorld() { System.out.println("Save World Like Human!"); }	
// }

//___________________________________________________________________

// Using Inheritance
class Human extends Spiderman {
// class Human extends Superman {
// class Human extends Wonderwoman {
	public void fly() 		{ super.fly(); 		 }
	public void saveWorld() { super.saveWorld(); }
}

// Composition Is Equivalent To Inheritance
// Using Composition
class HumanBetter {
	Spiderman power = new Spiderman();
	// Superman power = new Superman();
	// Wonderwoman power = new Wonderwoman();

	public void fly() 		{ power.fly(); 		 }
	public void saveWorld() { power.saveWorld(); }
}

// Polymorphic Human
// Composition Is Better Than To Inheritance
// 		Using Composition Mechanism
class HumanBest {
	Superpower power = null; // No Power Given

	public void fly() 		{ if (power != null ) power.fly(); 		 }
	public void saveWorld() { if (power != null ) power.saveWorld(); }
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

public class Experiments { 

	public static void playWithSpecials() {
		Spiderman s = new Spiderman();
		s.fly();
		s.saveWorld();

		Superman sup = new Superman();
		sup.fly();
		sup.saveWorld();
	}

	public static void playWithHuman() {
		Human h = new Human();
		h.fly();
		h.saveWorld();
	}

	public static void playWithHumanBetter() {
		HumanBetter hb = new HumanBetter();
		hb.fly();
		hb.saveWorld();
	}

	public static void playWithHumanBest() {
		HumanBest hb = new HumanBest();
		hb.power = new Spiderman();
		hb.fly();
		hb.saveWorld();

		hb.power = new Superman();
		hb.fly();
		hb.saveWorld();

		hb.power = new Wonderwoman();
		hb.fly();
		hb.saveWorld();

		hb.power = new HanumanJi();
		hb.fly();
		hb.saveWorld();
	}

	public static void main(String[] args) {
		System.out.println("\nHello Java! Welcome To Java!");
		
		System.out.println("\nFunction : playWithSpecials");
		playWithSpecials();

		System.out.println("\nFunction : playWithHuman");
		playWithHuman();

		System.out.println("\nFunction : playWithHumanBetter");
		playWithHumanBetter();

		System.out.println("\nFunction : playWithHumanBest");
		playWithHumanBest();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

//___________________________________________________________________
//___________________________________________________________________
