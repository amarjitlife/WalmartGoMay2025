
package main

import (
	"fmt"
	"time"
	"sync"
)

//___________________________________________________________________

func doSomething( from string ) {
	for i := 0 ; i < 3 ; i++ {
		fmt.Println( from, " : ", i )
		time.Sleep( time.Second * 2 )
	}
}

func playWithGoRoutines() {
	fmt.Println( time.Now().Format( time.RFC850 ) )

	go doSomething("Oyee Hoyeee!!!")
	go doSomething("Ye Dil Maangeee More!!!")

	// Anonymous Function: Function With Name
	//		Closure or Lambda Function
	// someFunction := func( message string ) {
	// 	for i := 0 ; i < 3 ; i++ {
	// 		fmt.Println( message, " : ", i )
	// 		time.Sleep( time.Second * 2 )
	// 	}
	// 	time.Sleep( time.Second * 3 )				
	// }

	// go someFunction("Hey Hey!!!")

	go func( message string ) {
		for i := 0 ; i < 3 ; i++ {
			fmt.Println( message, " : ", i )
			time.Sleep( time.Second * 2 )
		}
		time.Sleep( time.Second * 3 )				
	}("Hey Hey!!!")

	fmt.Println( time.Now().Format( time.RFC850 ) )

	time.Sleep( time.Second * 10 )				
	fmt.Println("Done: playWithGoRoutines")
}

// Function : playWithGoRoutines
// Thursday, 29-May-25 06:05:59 UTC
// Thursday, 29-May-25 06:05:59 UTC
// Hey Hey!!!  :  0
// Ye Dil Maangeee More!!!  :  0
// Oyee Hoyeee!!!  :  0
// Ye Dil Maangeee More!!!  :  1
// Hey Hey!!!  :  1
// Oyee Hoyeee!!!  :  1
// Oyee Hoyeee!!!  :  2
// Hey Hey!!!  :  2
// Ye Dil Maangeee More!!!  :  2
// Done: playWithGoRoutines

//___________________________________________________________________

// WHAT IS PARALLISM?
// WHAT IS CONCURRENCY?

//___________________________________________________________________

func playWithChannels() {
	messages := make( chan string )

	var messageRead string

	go func() {
		messages <- "Ping"
		time.Sleep( time.Second * 2 )

		messages <- "Pong"
		time.Sleep( time.Second * 2 )

		messages <- "Ting"
		time.Sleep( time.Second * 2 )

		messages <- "Tong"
		time.Sleep( time.Second * 2 )
	}()

	messageRead = <- messages
	fmt.Println( messageRead )

	messageRead = <- messages
	fmt.Println( messageRead )

	messageRead = <- messages
	fmt.Println( messageRead )

	messageRead = <- messages
	fmt.Println( messageRead )

	fmt.Println("Done: playWithChannels" )
}


//___________________________________________________________________
// MAP-REDUCE PATTERNS

func sum( numbers[] int, message chan int ) {
	result := 0
	for _, number := range numbers {
		result += number
	}

	// Writing To Channel
	message <- result
}

func playWithSum() {
	message := make( chan int )
	numbers := []int { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -9, -8, -7 }

	// Map Stage
	go sum( numbers[ : len(numbers) / 2] , message )
	go sum( numbers[ len(numbers) / 2 : ], message )
	fmt.Println("Go Routines Started: ")

	sum1, sum2 := <- message, <- message

	// Reduce Stage
	total := sum1 + sum2
	fmt.Println("Total Sum: ", total )
}

//___________________________________________________________________

// Argument pings Is Write Only Channel
func ping( pings chan <- string, data string ) {
	pings <- data
}

func pong( pings <- chan string, pongs chan <- string ) {
	data := <- pings
	pongs <- data
}

func playWithReadWriteOnlyChannels() {
	pings := make( chan string, 1 )
	pongs := make( chan string, 1 )

	ping( pings, "Oyee Hoyee!!!")
	pong( pings, pongs )

	fmt.Println( <- pongs )
}


//___________________________________________________________________

// DESIGN PRINCIPLE
// 		One suggestion (made by Rob Pike) for concurrent programming 
// 			is don't (let computations) communicate by sharing memory, 
// 			(let them) share memory by communicating (through channels). 
// 			(We can view each computation as a goroutine in Go programming.)


func worker( done chan bool ) {
	fmt.Println("Worker: Working...")
	time.Sleep( time.Second * 3 )
	fmt.Println("Worker: Work Done!!!")	

	done <- true
}

func playWithWorkers() {
	done := make( chan bool, 1 )

	go worker( done )

	workerStatus := <- done
	fmt.Println("Worker Status: Work Done? :: ", workerStatus)
}


//___________________________________________________________________

func playWithClosingChannel() {
	messages := make( chan string, 2 )
	messages <- "Oyee Hoyeee!!!"
	messages <- "Ye Dil Maaangeee More!!!"

	close( messages )

	// Can Use Loop To Read From Channel
	for message := range messages {
		fmt.Println( message )
	}
}

//___________________________________________________________________

func fibonacci( count int, fibos chan int ) {
	x, y := 0, 1

	for i := 0 ; i < count ; i++ {
		fibos <- x
		x, y = y, x + y
	}
	close( fibos )
}

func playWithFibonaccis() {
	fibos := make( chan int, 10 )

	go fibonacci( cap( fibos ), fibos )

	for fibo := range fibos {
		fmt.Println( fibo )
	}
} 

//___________________________________________________________________

func fibonacciAgain( fibos chan int, quit chan bool ) {
	x, y := 0, 1
	// var order bool
	for {
		select {
		case fibos <- x:
			x, y = y, x + y
		case order := <- quit:
			if order == true {
				fmt.Println("Fibonacci Quit!")
				return
			}
		}
	}
}

func playWithFibonaccisAgain() {
	fibos 	:= make( chan int, 10 )
	quit 	:= make( chan bool )

	go func() {
		for i := 0 ; i < 10 ; i++ {
			fmt.Println( <- fibos )
		}
		quit <- true
	}()
	fibonacciAgain( fibos, quit )
} 

//___________________________________________________________________

// HOME WORK
// HOME WORK
// HOME WORK
// HOME WORK

//___________________________________________________________________

// import "sync"

// SafeCounter is safe to use concurrently.
type SafeCounter struct {
	mu sync.Mutex
	v  map[string]int
}

// Inc increments the counter for the given key.
func (c *SafeCounter) Inc(key string) {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	c.v[key]++
	c.mu.Unlock()
}

// Value returns the current value of the counter for the given key.
func (c *SafeCounter) Value(key string) int {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	defer c.mu.Unlock()
	return c.v[key]
}

func playWithSafeCounter() {
	safeCounter := SafeCounter{v: make(map[string]int)}
	
	for i := 0; i < 1000; i++ {
		go safeCounter.Inc("somekey")
	}

	time.Sleep(time.Second)
	fmt.Println( safeCounter.Value("somekey") )
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	// fmt.Println("\nFunction : playWithGoRoutines")
	// playWithGoRoutines()

	// fmt.Println("\nFunction : playWithChannels")
	// playWithChannels()

	// fmt.Println("\nFunction : playWithSum")
	// playWithSum()

	// fmt.Println("\nFunction : playWithReadWriteOnlyChannels")
	// playWithReadWriteOnlyChannels()

	// fmt.Println("\nFunction : playWithWorkers")
	// playWithWorkers()

	// fmt.Println("\nFunction : playWithClosingChannel")
	// playWithClosingChannel()

	fmt.Println("\nFunction : playWithFibonaccis")
	playWithFibonaccis()

	fmt.Println("\nFunction : playWithFibonaccisAgain")
	playWithFibonaccisAgain()

	fmt.Println("\nFunction : playWithSafeCounter")
	playWithSafeCounter()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
}

//___________________________________________________________________
//___________________________________________________________________
