
package main

import (
	"fmt"
)

//___________________________________________________________________
// Interfaces Defines
//		Abstract Capability!
// 		What To Do!
type Superpower interface {
	Fly()
	SaveWorld()
}

//___________________________________________________________________

// Structure Defines
// 		Concrete Capability
//		How, When, Where, Which Way To Do!
type Spiderman struct {}
type Superman struct {}
type Human struct {} 

func (s Spiderman) Fly() {
	fmt.Println("Fly Like Spiderman!")
}

func (s Spiderman) SaveWorld() {
	fmt.Println("Save World Like Spiderman!")
}

func (s Superman) Fly() {
	fmt.Println("Fly Like Superman!")
}

func (s Superman) SaveWorld() {
	fmt.Println("Save World Like Superman!")
}

func (s Human) Fly() {
	fmt.Println("Fly Like Human!")
}

func (s Human) SaveWorld() {
	fmt.Println("Save World Like Human!")
}

//___________________________________________________________________

func playWithSpecials() {
	s := Spiderman{}

	s.Fly()
	s.SaveWorld()

	su := Superman{}
	su.Fly()
	su.SaveWorld()
}


func playWithHumans() {
	h := Human{}

	h.Fly()
	h.SaveWorld()
}

//___________________________________________________________________

func playWith( power Superpower ) {
	power.Fly()
	power.SaveWorld()
}

func playWithAll() {
	spiderman 	:= Spiderman{ }
	superman 	:= Superman{ }
	human 		:= Human{ }

	playWith( spiderman )
	playWith( superman )
	playWith( human )
}

func playWithAllAgain() {
	all :=  [ ]Superpower { Spiderman{ }, Superman{ }, Human{  } }
 	for _, someone := range all {
 		playWith( someone )
 	}
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithSpecials")
	playWithSpecials()

	fmt.Println("\nFunction : playWithHumans")
	playWithHumans()

	fmt.Println("\nFunction : playWithAll")
	playWithAll()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
}

//___________________________________________________________________
//___________________________________________________________________
