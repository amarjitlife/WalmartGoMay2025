
package firstthing

import "fmt"

func HelloTing() {
    fmt.Println("Hello Ting!!!")
}

