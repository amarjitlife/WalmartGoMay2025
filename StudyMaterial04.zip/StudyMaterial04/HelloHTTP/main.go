

package main

import (
	"fmt"
	"rsc.io/quote"
	"net/http"
)

func hello( w http.ResponseWriter, req *http.Request ) {
	fmt.Fprintf( w, "Hello Gabbar Singh!!!" )
}

func main() {
	// fmt.Println("Hello, World!!!")
	fmt.Println( quote.Go() )

	http.HandleFunc( "/hello", hello )
	http.ListenAndServe(":8080", nil)
}


