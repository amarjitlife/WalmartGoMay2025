package main

import (
	"fmt"
	// "math"
	"strings"
	// "bytes"
	// "strconv"
	// "cmplx"
)

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Complex Number
//		a + b i
//		float32, float64 Follows IEEE 754 Standard
//		complex64: Means a And b Are Type Of float32
//		complex128: Means a And b Are Type Of float64

func playWithComplexTypes() {
	var x complex128 = complex(1, 2) 	// 1 + 2i
	var y complex128 = complex(3, 4) 	// 3 + 4i
	fmt.Println( x )
	fmt.Println( y )
	fmt.Println( x + y  )
	fmt.Println( x * y  )
	fmt.Println( real( x ) )  
	fmt.Println( imag( x ) )  

	fmt.Println( 1i * 1i )  

	xx := 1 + 2i
	yy := 3 + 4i
	fmt.Println( xx )
	fmt.Println( yy )
	fmt.Println( xx + yy  )
	fmt.Println( xx * yy  )
	fmt.Println( real( xx ) )  
	fmt.Println( imag( xx ) )  
	// fmt.Println( cmplx.Sqrt( -1 ) )
}

//__________________________________________________

func basename( s string ) string {
	for i := len( s ) - 1 ; i >= 0 ; i-- {
		if s[i] == '/' {
			s = s[ i + 1 : ] // Slicing
			break
		}
	}

	// for i := len( s ) - 1 ; i >= 0 ; i-- {
	// 	if s[i] == '.' {
	// 		s = s[ : i ] // Slicing
	// 		break
	// 	}
	// }

	return s
}

func basenameAgain( s string ) string {
	slash := strings.LastIndex( s, "/" )
	s = s[ slash + 1 : ]

	// if dot := strings.LastIndex( s, "." ) ; dot >= 0 {
	// 	s = s[ : dot ]
	// }
	return s
}

func playWithBaseName() {
	fmt.Println( basename( "/home/amarjit/Documents/Trainings/WalmartMay2025/Progress/Hello.go" ) )
	fmt.Println( basename( "/home/amarjit/Documents/Trainings/WalmartMay2025/Progress" ) )

	fmt.Println( basenameAgain( "/home/amarjit/Documents/Trainings/WalmartMay2025/Progress/Hello.go" ) )
	fmt.Println( basenameAgain( "/home/amarjit/Documents/Trainings/WalmartMay2025/Progress" ) )
}

// Reference Link: strings Pacakge 
// 		https://pkg.go.dev/strings
//		https://go.dev/blog/strings

//	
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main( ) {
	fmt.Println("\n\nFunction: playWithComplexTypes")
	playWithComplexTypes()

	fmt.Println("\n\nFunction: playWithBaseName")
	playWithBaseName()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
}
