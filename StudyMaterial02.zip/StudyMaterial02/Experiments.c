
#include <stdio.h>


//__________________________________________________

void playWithCString() {
	// C Pointers and Arrays Are Unsafe References
	char greeting[] = "Hello World!";
	char *something = "Hello World!";

	printf("\nValue: %s %s", greeting, something);

	char *start = greeting;
	printf("\nValue: %s %s", greeting, start);

	start[0] = 'X';
	printf("\nValue: %s %s", greeting, start);


	for ( int i = -10 ; i < 20 ; i++ ) {
		printf(" %c ", greeting[i] );
	}

	int aa[] = { 10, 20, 30, 40, 50 };

	for ( int i = -10 ; i < 20 ; i++ ) {
		printf(" %c ", aa[i] );
	}
}

// Function : playWithCString
// Value: Hello World! Hello World!
// Value: Hello World! Hello World!
// Value: Xello World! Xello World!

//__________________________________________________


void printArray( int a[], int len ) {
	printf("\n");
	for( int i = 0 ; i < len ; i++ ) {
		printf(" %d ", a[i] ) ;
	}
}

void doChange( int a[], int len ) {
	for( int i = 0 ; i < len ; i++ ) {
		a[i] = 99;
	}
}

void playWithArraysInC() {
	int a[5] = { 10, 20, 30, 40, 50 };

	printArray( a, 5 );
	doChange( a, 5 );
	printArray( a, 5 );	
}

// Function : playWithArraysInC
//  10  20  30  40  50 
//  99  99  99  99  99

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction : playWithCString");
	playWithCString();

	printf("\n\nFunction : playWithArraysInC");
	playWithArraysInC();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");	
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}

