
package main

import (
	"fmt"
	// "os"
	// "strconv"
	// "strings"
	// "bufio"
	// "unicode/utf8"
	// "unicode"
	// "io"
	// "encoding/json"
	// "log"
)

//__________________________________________________

func playWithDefaultInitialValues() {
	var a int
	var i8 int8
	var ui8 uint8

	var f1 float32
	var f2 float64

	var s string

	var c1 complex64 
	var c2 complex128

	var b bool

	fmt.Printf("%d %d %d\n", a, i8, ui8)
	fmt.Printf("%f %f\n", f1, f2)	
	fmt.Printf("%s \n", s)	
	fmt.Printf("%v %v", c1, c2)	
	fmt.Printf("%t \n", b)	
}

//__________________________________________________

func playWithArrays() {
	var a [3]int

	for index, value := range a {
		fmt.Printf("At Index: %d Value: %d\n", index, value )
	}

	fmt.Println( a[0], a[1] )
	fmt.Println( a[ len(a) - 1] )

	for _, value := range a {
		fmt.Printf("Value: %d\n", value )
	}

	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30  }

	fmt.Println("Length: ", len( q ) )
	for index, value := range q {
		fmt.Printf("At Index: %d Value: %d\n", index, value )
	}

	fmt.Println("Length: ", len( r ) )
	for index, value := range r {
		fmt.Printf("At Index: %d Value: %d\n", index, value )
	}

	// Type Will Be [4]int
	s := [...]int { 10, 20, 100, 111 }
	fmt.Println("Length: ", len( s ) )
	fmt.Println("Array: ", s )
	fmt.Printf("Array Type: %T\n", s )

	some := [4]int { 10, 20, 100  }
	fmt.Println("Length: ", len( some ) )
	fmt.Println("Array: ", some )
	fmt.Printf("Array Type: %T\n", some )

	someAgain := [...]int { 9 : -1 }
	fmt.Println("Length: ", len( someAgain ) )
	fmt.Println("Array: ", someAgain )
	fmt.Printf("Array Type: %T\n", someAgain )

	someAgain1 := [...]int { 2: 10, 5: 55, 9 : -1 }
	fmt.Println("Length: ", len( someAgain1 ) )
	fmt.Println("Array: ", someAgain1 )
	fmt.Printf("Array Type: %T\n", someAgain1 )

	aa := [2]int { 10, 20 }
	bb := [...] int { 10, 20 }
	cc := [2]int { 10, 30 }

	fmt.Println( aa == bb, aa == cc, bb == cc )

	dd := [3]int { 10, 30 }
	fmt.Println( dd )
	// fmt.Println( dd == aa )
		// invalid operation: dd == aa (mismatched types [3]int and [2]int)
}


//__________________________________________________

type Flags uint

const ( // STATUS BITs ARE DEFINED AS FOLLOWS
    FlagUp Flags = 1 << iota // is up
	FlagBroadcast		 	 // supports broadcast access capability
	FlagLoopback             // is a loopback interface
	FlagPointToPoint         // belongs to a point-to-point link
	FlagMulticast            // supports multicast access capability
)

func IsUp(v Flags) bool     { return v & FlagUp == FlagUp } // & (bitwise AND)
func TurnDown(v *Flags)     { *v &^= FlagUp }   // &^ (AND NOT): This is a bit clear operator.
func SetBroadcast(v *Flags) { *v |= FlagBroadcast } // | (bitwise OR)
func IsCast(v Flags) bool   { return v & (FlagBroadcast | FlagMulticast) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10001 true"
	
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10000 false"
	
	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp(v))   // "10010 false"
	fmt.Printf("%b %t\n", v, IsCast(v)) // "10010 true"
}

//__________________________________________________

// In C/C++/Java:
// 		By Default Arrays Are Pass By Reference

// In Go:
// 		By Default Arrays Are Pass By Value
//		Arrays Are Safe Types
//		Pointers Are Safe Pointers

func changeArray( a [5]int ) {
	fmt.Println("Array Inside Before Change: ", a)
	for i, _ := range a {
		a[i] = 99
	}
	fmt.Println("Array Inside After Change : ", a)
}

// Passing Pointer Array To Achieve Pass By Reference
func changeArray1( a *[5]int ) {
	fmt.Println("Array Inside Before Change: ", a)
	for i, _ := range a {
		a[i] = 99
	}
	fmt.Println("Array Inside After Change : ", a)
}

// Passing Slice To An Array To Achieve Pass By Reference
func changeArray2( slice []int ) { // Slice []int To Array Of int Type Data
	fmt.Println("Array Inside Before Change: ", slice)
	for i, _ := range slice {
		slice[i] = 99
	}
	fmt.Println("Array Inside After Change : ", slice)
}

func playWithChangeArrays() {
	var aa [5]int = [5]int { 10, 20, 30, 40, 50 }

	fmt.Println("Array Outside Before Change: ", aa )
	changeArray( aa )
	fmt.Println("Array Outside After  Change: ", aa )	

	var bb [5]int = [5]int { 10, 20, 30, 40, 50 }

	fmt.Println("Array Outside Before Change: ", bb )
	changeArray1( &bb ) // Pass By Reference
	fmt.Println("Array Outside After  Change: ", bb )	

	var cc [5]int = [5]int { 10, 20, 30, 40, 50 }

	fmt.Println("Array Outside Before Change: ", cc )
	changeArray2( cc[ : 3 ] ) // Passing Slice To Achieve Pass By Reference
	fmt.Println("Array Outside After  Change: ", cc )	

	fmt.Println("Array Outside Before Change: ", cc )
	changeArray2( cc[ : ] ) // Passing Slice To Achieve Pass By Reference
	fmt.Println("Array Outside After  Change: ", cc )	
}

// Function: playWithChangeArrays
// Array Outside Before Change:  [10 20 30 40 50]
// Array Inside Before Change:   [10 20 30 40 50]
// Array Inside After Change :   [99 99 99 99 99]
// Array Outside After  Change:  [10 20 30 40 50]

// Function: playWithChangeArrays
// Array Outside Before Change:  [10 20 30 40 50]
// Array Inside Before Change:  &[10 20 30 40 50]
// Array Inside After Change :  &[99 99 99 99 99]
// Array Outside After  Change:  [99 99 99 99 99]

//__________________________________________________

func playWithSlices() {
	months := [...]string{ 0 : "", "Jan", "Feb", "Mar", "Apr", "May",
					  "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }

	fmt.Println( "Months: ", months )
	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]
	summer := months[ 2 : 7 ]

	fmt.Println("Quater 1: ", quater1 )
	fmt.Println("Quater 2: ", quater2 )
	fmt.Println("Summer  :", summer )

	// fmt.Println( quater1 == quater2 )
		// ./GoComposite.go:220:15: invalid operation: 
		//			quater1 == quater2 (slice can only be compared to nil)

	for _, s := range summer {
		for _, q := range quater2 {
			if s == q {
				fmt.Printf(" %s Appears In Both \n", s )
			}
		}
	}
}

// Function: playWithSlices
// Months:    [ Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec]
// Quater 1:  [Jan Feb Mar]
// Quater 2:  [Apr May Jun]
// Summer  :  [Feb Mar Apr May Jun]

//__________________________________________________

func reverse( slice []int ) {
	for i, j := 0, len( slice ) -1  ;  i < j  ;  i, j = i + 1, j - 1 {
		slice[i], slice[j] = slice[j], slice[i]
	}
}

// In Go Slices Are Pass By Reference
// func slicesEqual(x []int, y []int ) bool {
func slicesEqual(x, y []int ) bool {
	if len( x ) != len( y ) {
		return false 
	}

	for i := range x {
		if x[i] != y[i] {
			return false
		}
	}
	return true
}

func playWithArrayAndSlices() {
	// a Is An Array
	a := [...]int { 10, 20, 30, 40, 50, 60, 70, 80, 90 }
	
	fmt.Println( a )
	reverse( a [ : ] )
	fmt.Println( a )

	// s Is A Slice: Array Syntax Withoud Size Information
	s := []int { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	
	fmt.Println( s )
	reverse ( s[ : 5 ] ) 
	fmt.Println( s )
	reverse ( s[ 5 :  ] ) 
	fmt.Println( s )

	changeArray2( s[ 3 : 6 ] )
	fmt.Println( s )

	slice1 := a[ 2 : 6 ]
	slice2 := a[ 2 : 6 ]
	slice3 := a[ 5 : 8 ]

	// invalid operation: slice1 == slice2 (slice can only be compared to nil)
	// fmt.Println( slice1 == slice2 )
	// fmt.Println( slice1 == slice3 )
	// fmt.Println( slice2 == slice3 )

	fmt.Println( slicesEqual( slice1, slice2 )  )
	fmt.Println( slicesEqual( slice1, slice2 )  )
	fmt.Println( slicesEqual( slice2, slice3 )  )
}

//__________________________________________________


//_____________________________________________________________________________________
// 						
// 									GO SLICES CONCEPTS
//_____________________________________________________________________________________

// Slices represent variable-length sequences whose elements all have the same type. 
// 	A slice type is written []T, where the elements have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to a subsequence (or perhaps all)
// 	 of the elements of an array, which is known as the slice’s underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that is reachable through the slice, 
// 			which is not necessarily the array’s first element. 
// 		The length is the number of slice elements; it can’t exceed the capacity, 
// 			which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 

// 		The built-in functions len and cap return those values.

// The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
// 	Creates a new slice that refers to elements i through j-1 of the sequence s, 
// 	which may be an array variable, a pointer to an array, or another slice. 
// 	The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j is omitted, it’s len(s). 

// 	Thus the slice months[1:13] refers to the whole range of valid months, 
// 	as does the slice months[1:]; the slice months[:] refers to the whole array.


//__________________________________________________

func playWithSliceFunctions() {
	s := make( []string, 3 ) // Creating Empty Slice Having Background Array Of Len/Cap Of 3
	// Created Slice DataStructure: Pointer To Nil, Len = 3, Cap = 3

	fmt.Printf("\nSlice %v:  Type: %T", s, s )
	fmt.Printf("\nLength %d:  Capacity: %d", len( s ) , cap( s ))

	fmt.Println()
	fmt.Println( s[0] )
	fmt.Println( s[1] )
	fmt.Println( s[2] )

	s[0] = "A"
	s[1] = "B"
	s[2] = "C"

	fmt.Printf("\nSlice %v:  Type: %T", s, s )
	fmt.Printf("\nLength %d:  Capacity: %d", len( s ) , cap( s ))	
	fmt.Println()
	fmt.Println( s[0] )
	fmt.Println( s[1] )
	fmt.Println( s[2] )

	s = append( s, "D" )
	fmt.Printf("\nSlice %v:  Type: %T", s, s )
	fmt.Printf("\nLength %d:  Capacity: %d", len( s ) , cap( s ))	

	s = append( s, "E", "F" )
	fmt.Printf("\nSlice %v:  Type: %T", s, s )
	fmt.Printf("\nLength %d:  Capacity: %d", len( s ) , cap( s ))	

	s = append( s, "G", "H" )
	fmt.Printf("\nSlice %v:  Type: %T", s, s )
	fmt.Printf("\nLength %d:  Capacity: %d", len( s ) , cap( s ))	

	c := make( []string, len( s ) )
	// Shallow Copy
	c = s // Slices Are Reference Leading To Reference Assignment

	fmt.Printf("\nSlice %v:  Type: %T", s, s )
	fmt.Printf("\nSlice %v:  Type: %T", c, c )
	fmt.Printf("\nLength %d:  Capacity: %d", len( s ) , cap( s ))	
	fmt.Printf("\nLength %d:  Capacity: %d", len( c ) , cap( c ))	

	s[0] = "Hello!"
	fmt.Printf("\nSlice %v:  Type: %T", s, s )
	fmt.Printf("\nSlice %v:  Type: %T", c, c )

	c = append(c, "XX")
	fmt.Printf("\nSlice %v:  Type: %T", s, s )
	fmt.Printf("\nSlice %v:  Type: %T", c, c )
	fmt.Printf("\nLength %d:  Capacity: %d", len( s ) , cap( s ))	
	fmt.Printf("\nLength %d:  Capacity: %d", len( c ) , cap( c ))	

	c[5] = "MM"
	fmt.Printf("\nSlice %v:  Type: %T", s, s )
	fmt.Printf("\nSlice %v:  Type: %T", c, c )

	ss := make( []string, 0 )
	fmt.Printf("\nSlice %v:  Type: %T", ss, ss )
	fmt.Printf("\nLength %d:  Capacity: %d", len( ss ) , cap( ss ))	

	mm := make( []string, 0 )
	mm = append( mm, "AA", "BB", "CC", "DD" )

	cc := make( []string, len( mm ) )

	fmt.Printf("\nSlice %v:  Type: %T", mm, mm )
	fmt.Printf("\nSlice %v:  Type: %T", cc, cc )
	fmt.Printf("\nLength %d:  Capacity: %d", len( mm ) , cap( mm ))	
	fmt.Printf("\nLength %d:  Capacity: %d", len( cc ) , cap( cc ))	

	copy( cc, mm ) // Deep Copy

	fmt.Printf("\nSlice %v:  Type: %T", mm, mm )
	fmt.Printf("\nSlice %v:  Type: %T", cc, cc )
	fmt.Printf("\nLength %d:  Capacity: %d", len( mm ) , cap( mm ))	
	fmt.Printf("\nLength %d:  Capacisty: %d", len( cc ) , cap( cc ))	

	cc[0] = "Good Afternoon!"

	fmt.Printf("\nSlice %v:  Type: %T", mm, mm )
	fmt.Printf("\nSlice %v:  Type: %T", cc, cc )
	fmt.Printf("\nLength %d:  Capacity: %d", len( mm ) , cap( mm ))	
	fmt.Printf("\nLength %d:  Capacity: %d", len( cc ) , cap( cc ))	

	tt := []string{ "Ding", "Dong", "Ting", "Tong" }
	fmt.Printf("\nSlice %v:  Type: %T", tt, tt )
	fmt.Printf("\nLength %d:  Capacity: %d", len( tt ) , cap( tt ))	
}

// Function: playWithSliceFunctions

// Slice [  ]:  Type: []string
// Length 3:  Capacity: 3

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

func main( ) {
	fmt.Println("\n\nFunction: playWithDefaultInitialValues")
	playWithDefaultInitialValues()

	fmt.Println("\n\nFunction: playWithArrays")
	playWithArrays()

	fmt.Println("\n\nFunction: playWithFlags")
	playWithFlags()

	fmt.Println("\n\nFunction: playWithChangeArrays")
	playWithChangeArrays()

	fmt.Println("\n\nFunction: playWithSlices")
	playWithSlices()

	fmt.Println("\n\nFunction: playWithArrayAndSlices")
	playWithArrayAndSlices()

	fmt.Println("\n\nFunction: playWithSliceFunctions")
	playWithSliceFunctions()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
}
