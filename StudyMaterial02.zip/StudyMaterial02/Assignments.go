
_____________________________________________________________

DAY 01
_____________________________________________________________

Assignments A1: Revise and Practice Go Code
	Till Now Done In The Class

Assignments A2: Reading Documentation and Practice Go Code	
	Reference Link: Read Flag Documentation
			https://pkg.go.dev/flag

	Reference Link: Read Flag Documentation
			https://pkg.go.dev/fmt

	Reference Link: strings Pacakge 
			https://pkg.go.dev/strings
			https://go.dev/blog/strings

Assignments A3: Reading Pointers and Array [ MUST MUST MUST ]
	Chapter 05: Pointers and Array

	Reference: The C Programming Language, 2nd Editon
					By Kernigham and Dennis Ritiche

Assignments A4: For Advanced and Inquistive Learners [ OPTIONAL ]
	── References
	    └── DataTypesInLinuxKernel.pdf

_____________________________________________________________

DAY 02
_____________________________________________________________


Assignments A1: Revise and Practice Go Code
	Till Now Done In The Class

Assignments A2: Reading Documentation and Practice Go Code	
	Reference Link:
			https://pkg.go.dev/bytes

	Reference Link:
			https://pkg.go.dev/strconv

Assignments A3: 
	Q1: Deeper Understanding Of Unicode Strings Design
		How Unicode Strings Are Stored In Go, Java and Python, JavaScript, C/C++?
		Reason Unicode String Design Across Languages?
		How Unicode Standard Identifies Which Unicode Character Starts/Ends
				Because Variable Length
	Q2: Deeper Understanding Of Slices In Go and Python?

Assignments A4: Reading Pointers and Array [ MUST MUST MUST ]
	Chapter 05: Pointers and Array

	Reference: The C Programming Language, 2nd Editon
					By Kernigham and Dennis Ritiche

_____________________________________________________________

DAY 03
_____________________________________________________________


_____________________________________________________________

DAY 04
_____________________________________________________________

